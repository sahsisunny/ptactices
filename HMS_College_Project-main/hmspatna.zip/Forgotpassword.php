<?php
include("common/header.php");
?>

<div class="wrapper col4 center" >
  <div id="container">
    <!-- Blank Space -->
    <p>&nbsp;</p>
    <h1>Please contact your appoint Doctors</h1>
    <p>&nbsp;</p>

  </div>
</div>


<?php
include("common/footer.php");
?>